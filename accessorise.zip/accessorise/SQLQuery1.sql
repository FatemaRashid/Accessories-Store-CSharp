﻿CREATE TABLE Accessoris (
Id INT PRIMARY KEY IDENTITY (1,1),
Type NVARCHAR (100) NOT NULL,
Color NVARCHAR (100) NOT NULL,
Material NVARCHAR (100) NOT NULL,
Size NVARCHAR (100) NOT NULL,
Price DECIMAL (16,2) NOT NULL,
Image NVARCHAR (255) NOT NULL,
MadeAt DATETIME  NOT NULL);


INSERT INTO Accessoris (Type, Color, Material, Size, Price, Image, MadeAt) VALUES
('Earring', 'Gold', 'Gold', '0.5g', 12.00, 'earring1.jpg', GETDATE()),
('Earring', 'Gold', 'Gold', '0.5g', 12.00, 'earring2.jpg', GETDATE()),
('Earring', 'Gold', 'Gold', '0.5g', 12.00, 'earring3.jpg', GETDATE()),
('Chain', 'Gold', 'Gold', '0.4g', 15.00, 'Chain3.jpg', GETDATE()),
('Chain', 'Gold', 'Gold', '0.4g', 15.00, 'Chain1.jpg', GETDATE()),
('Chain', 'Gold', 'Gold', '0.4g', 15.00, 'Chain2.jpg', GETDATE()),
('Ring', 'Gold', 'Gold', '0.5g', 20.00, 'Ring2.jpg', GETDATE()),
('Ring', 'Gold', 'Gold', '0.5g', 20.00, 'Ring1.jpg', GETDATE()),
('Ring', 'Silver', 'Silver', '0.5g', 20.00, 'Ring3.jpg', GETDATE()),
('Bracelet', 'Gold', 'Gold', '0.3g', 13.00, 'Bracelet1.jpg', GETDATE()),
('Bracelet', 'Gold', 'Gold', '0.3g', 13.00, 'Bracelet3.jpg', GETDATE()),
('Bracelet', 'Silver', 'Silver', '0.3g', 13.00, 'Bracelet2.jpg', GETDATE());



