﻿using Microsoft.AspNetCore.Mvc;
using accessorise.Services;
using accessorise.Models;
using Microsoft.EntityFrameworkCore;
using System.IO;
using static System.Net.Mime.MediaTypeNames;

namespace accessorise.Controllers
{
    public class AccsessoriesController : Controller
    {
        private readonly ApplicationDBContext _context;
        private readonly IWebHostEnvironment _environment;

        public AccsessoriesController(ApplicationDBContext context, IWebHostEnvironment environment)
        {
            _context = context;
            _environment = environment;
        }

        public IActionResult Index()
        {
            var products = _context.Accessoris.ToList();
            return View(products);
        }

        public IActionResult Create()
        {
            return View();
        }

        [HttpPost]
        public IActionResult Create(ProductDto productDto)
        {
            if (productDto.Image == null)
            {
                ModelState.AddModelError("Image", "the image file is required");
            }

            if (!ModelState.IsValid)
            {
                return View(productDto);
            }
            string newFileName = DateTime.Now.ToString("yyyyMMddHHmmssfff");
            newFileName += Path.GetExtension(productDto.Image!.FileName);

            string imageFullPath = _environment.WebRootPath + "/image/" + newFileName;
            using (var stream = System.IO.File.Create(imageFullPath))
            {
                productDto.Image.CopyTo(stream);
            }

            {
                var product = new AccessoriStor
                {
                    Type = productDto.Type,
                    Color = productDto.Color,
                    Material = productDto.Material,
                    Size = productDto.Size,
                    Price = productDto.Price,
                    Image = newFileName,
                    MadeAt = DateTime.Now
                };

                _context.Accessoris.Add(product);
                _context.SaveChanges();

                return RedirectToAction("Index");
            }
        }


        public IActionResult Edit(int id)
        {
            var product = _context.Accessoris.Find(id);
            if (product == null)
            {
                return RedirectToAction("Index");
            }

            var productDto = new ProductDto
            {
                Type = product.Type,
                Color = product.Color,
                Material = product.Material,
                Size = product.Size,
                Price = product.Price
            };

            ViewData["Id"] = product.Id;
            ViewData["Image"] = product.Image;
            ViewData["MadeAt"] = product.MadeAt.ToString("MM/dd/yyyy");

            return View(productDto);
        }

        [HttpPost]
        public IActionResult Edit(int id, ProductDto productDto)
        {
            var product = _context.Accessoris.Find(id); // Note: use lowercase 'cars'
            if (product == null)
            {
                return RedirectToAction("Index");
            }
            if (!ModelState.IsValid)
            {
                ViewData["Id"] = product.Id;
                ViewData["Image"] = product.Image;
                ViewData["MadeAt"] = product.MadeAt.ToString("MM/dd/yyyy");

                return View(productDto);
            }

            string newFileName = product.Image;
            if (productDto.Image != null)
            {
                newFileName = DateTime.Now.ToString("yyyyMMddHHmmssfff");
                newFileName += Path.GetExtension(productDto.Image.FileName);

                string imageFullPath = Path.Combine(_environment.WebRootPath, "image", newFileName);
                using (var stream = System.IO.File.Create(imageFullPath))
                {
                    productDto.Image.CopyTo(stream);
                }

                string oldImageFullPath = Path.Combine(_environment.WebRootPath, "image", product.Image);
                System.IO.File.Delete(oldImageFullPath);
            }
            product.Type = productDto.Type;
            product.Color = productDto.Color;
            product.Material = productDto.Material;
            product.Size = productDto.Size;
            product.Price = productDto.Price;
            product.Image = newFileName;

            _context.SaveChanges();

            return RedirectToAction("Index");
        }


        public IActionResult Delete(int id)
        {
            var product = _context.Accessoris.Find(id);
            if (product == null)
            {
                return RedirectToAction("Index");
            }
            string imageFullPath = Path.Combine(_environment.WebRootPath, "image", product.Image);
            System.IO.File.Delete(imageFullPath);

            _context.Accessoris.Remove(product);
            _context.SaveChanges();

            return RedirectToAction("Index");
        }
    }
}
