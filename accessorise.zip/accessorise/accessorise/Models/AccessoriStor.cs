﻿using Microsoft.EntityFrameworkCore;
using System.ComponentModel.DataAnnotations;

namespace accessorise.Models
{
    public class AccessoriStor
    {
        public int Id { get; set; }
        public string Type { get; set; } = "";
        public string Color { get; set; } = "";
        public string Material { get; set; } = "";
        public string Size { get; set; } = "";
        public decimal Price { get; set; }
        public string Image { get; set; } = "";
        public DateTime MadeAt { get; set; }
    }
}
