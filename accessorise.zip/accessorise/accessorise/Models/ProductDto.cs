﻿using Microsoft.EntityFrameworkCore;
using System.ComponentModel.DataAnnotations;

namespace accessorise.Models
{
    public class ProductDto
    {
        //[Required, MaxLength(100)]
        //public string Name { get; set; } = "";

        [Key]
        public int Id { get; set; } 

        [Required, MaxLength(100)]
        public string Type { get; set; } = "";

        [Required, MaxLength(100)]
        public string Color { get; set; } = "";

        [Required, MaxLength(100)]
        public string Material { get; set; } = "";

        public string? Size { get; set; } = "";

        [Required]
        public decimal Price { get; set; }

        public IFormFile? Image { get; set; }
    }
}
